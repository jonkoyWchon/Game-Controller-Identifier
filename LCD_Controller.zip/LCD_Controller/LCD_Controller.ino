#include <LiquidCrystal.h>

// initialize the library by associating any needed LCD interface pin
// with the arduino pin number it is connected to
const int rs = 12, en = 11, d4 = 5, d5 = 4, d6 = 3, d7 = 2;
LiquidCrystal lcd(rs, en, d4, d5, d6, d7);

void setup() {
  Serial.begin(9600);
  lcd.begin(16,2);
  lcd.print("Waiting...");
}

void loop() {
  if (Serial.available() > 0) {

    String message = Serial.readStringUntil('\n');
    message.trim();

    if (message == "on") {
      lcd.clear();
      lcd.print("Controller");
    }

    else if (message == "off") {
      lcd.clear();
      lcd.print("Background");
    }
  }
}